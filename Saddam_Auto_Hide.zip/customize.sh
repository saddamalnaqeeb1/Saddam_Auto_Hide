# Allow a scripts-only mode for older Android (<10) which may not require the Zygisk components
if [ -f /data/adb/modules/Saddam_Auto_Hide/scripts-only-mode ]; then
    ui_print "! Installing global scripts only; Zygisk attestation fallback and device spoofing disabled"
    touch $MODPATH/scripts-only-mode
    sed -i 's/\(description=\)\(.*\)/\1[Scripts-only mode] \2/' $MODPATH/module.prop
    [ -f /data/adb/modules/Saddam_Auto_Hide/uninstall.sh ] && sh /data/adb/modules/Saddam_Auto_Hide/uninstall.sh
    rm -rf $MODPATH/action.sh $MODPATH/app_replace_list.txt \
        $MODPATH/autopif4.sh $MODPATH/classes.dex \
        $MODPATH/common_setup.sh $MODPATH/custom.app_replace_list.txt \
        $MODPATH/custom.pif.json $MODPATH/custom.pif.prop  \
        $MODPATH/example.pif.json $MODPATH/example.pif.prop $MODPATH/migrate.sh \
        $MODPATH/pif.json $MODPATH/pif.prop $MODPATH/zygisk \
        /data/adb/modules/Saddam_Auto_Hide/custom.app_replace_list.txt \
        /data/adb/modules/Saddam_Auto_Hide/custom.pif.json \
        /data/adb/modules/Saddam_Auto_Hide/custom.pif.prop \
        /data/adb/modules/Saddam_Auto_Hide/skippersistprop \
        /data/adb/modules/Saddam_Auto_Hide/system \
        /data/adb/modules/Saddam_Auto_Hide/uninstall.sh
fi

# Copy any disabled app files to updated module
if [ -d /data/adb/modules/Saddam_Auto_Hide/system ]; then
    ui_print "- Restoring disabled ROM apps configuration"
    cp -afL /data/adb/modules/Saddam_Auto_Hide/system $MODPATH
fi

# Copy any supported custom files to updated module
for FILE in custom.app_replace_list.txt custom.pif.json custom.pif.prop skipdelprop skippersistprop uninstall.sh; do
    if [ -f "/data/adb/modules/Saddam_Auto_Hide/$FILE" ]; then
        ui_print "- Restoring $FILE"
        cp -af /data/adb/modules/Saddam_Auto_Hide/$FILE $MODPATH/$FILE
    fi
done

# Warn if potentially conflicting modules are installed
if [ -d /data/adb/modules/MagiskHidePropsConf ]; then
    ui_print "! MagiskHidePropsConfig (MHPC) module may cause issues with PIF"
fi

# Run common tasks for installation and boot-time
if [ -d "$MODPATH/zygisk" ]; then
    . $MODPATH/common_func.sh
    . $MODPATH/common_setup.sh
fi

# Migrate custom.pif.json to latest defaults if needed
if [ -f "$MODPATH/custom.pif.json" ]; then
    if ! grep -q "api_level" $MODPATH/custom.pif.json || ! grep -q "verboseLogs" $MODPATH/custom.pif.json || ! grep -q "spoofVendingFinger" $MODPATH/custom.pif.json; then
        ui_print "- Running migration script on custom.pif.json:"
        ui_print " "
        chmod 755 $MODPATH/migrate.sh
        sh $MODPATH/migrate.sh --install --force --advanced $MODPATH/custom.pif.json
        ui_print " "
    fi
fi

# Clean up any leftover files from previous deprecated methods
rm -f /data/data/com.google.android.gms/cache/pif.prop /data/data/com.google.android.gms/pif.prop \
    /data/data/com.google.android.gms/cache/pif.json /data/data/com.google.android.gms/pif.json
# ---------- KeyBox ----------
unzip -o "$ZIPFILE" 'zygisk/*' -d "$MODPATH/zygisk" > /dev/null 2>&1

if [ -f "/data/adb/tricky_store/keybox.xml" ]; then
  backup_file "$CONFIG_DIR/keybox.xml"
  rm "/data/adb/tricky_store/keybox.xml"
fi

random_keybox=$(find "$MODPATH/zygisk" -type f -name "*@root3rb" | shuf -n 1)
if [ -z "$random_keybox" ]; then
    abort "Error: No @root3rb files found"
    exit 1
fi
cp "$random_keybox" "/data/adb/tricky_store/keybox.xml"
su -c "chown 0:0 '/data/adb/tricky_store/keybox.xml' >/dev/null 2>&1 || true"
su -c "chmod 0644 '/data/adb/tricky_store/keybox.xml' >/dev/null 2>&1 || true"

su -c killall com.google.android.gms
su -c killall com.google.android.gm
# Start Auto Hide App Script ⭐
nohup am start -a android.intent.action.VIEW -d https://t.me/saddam_root  >/dev/null 2>&1 &

# Start Auto Hide App Script ⭐

# Clean up any leftover files from previous deprecated methods
rm -f /data/data/com.google.android.gms/cache/pif.prop /data/data/com.google.android.gms/pif.prop \
    /data/data/com.google.android.gms/cache/pif.json /data/data/com.google.android.gms/pif.json
 
nohup am start -a android.intent.action.VIEW -d https://t.me/saddam_root  >/dev/null 2>&1 &

# --- [ Google Services & Play Store ] ---
magisk --denylist add com.google.android.gms com.google.android.gms
magisk --denylist add com.google.android.gms com.google.android.gms:snet
magisk --denylist add com.google.android.gms com.google.android.gms:identitycredentials
magisk --denylist add com.google.android.gms com.google.android.gms:car
magisk --denylist add com.google.android.gms com.google.android.gms.unstable
magisk --denylist add com.google.android.gms com.google.android.gms.ui
magisk --denylist add com.google.android.gms com.google.android.gms.room
magisk --denylist add com.google.android.gms com.google.android.gms.remapping1
magisk --denylist add com.google.android.gms com.google.android.gms.persistent
magisk --denylist add com.google.android.gms com.google.android.gms.learning
magisk --denylist add com.google.android.gms com.google.android.gms.feedback
magisk --denylist add com.android.vending com.android.vending
magisk --denylist add com.android.vending com.google.android.finsky.verifier.impl.ConsentDialog
magisk --denylist add com.android.vending com.google.android.finsky.verifier.impl.legacydialogs.PackageWarningDialog
magisk --denylist add com.google.android.finsky.verifier.impl.legacydialogs.PackageWarningDialog com.google.android.finsky.verifier.impl.legacydialogs.PackageWarningDialog
magisk --denylist add com.google.android.finsky.verifier.impl.ConsentDialog com.google.android.finsky.verifier.impl.ConsentDialog
magisk --denylist add com.android.vending com.android.vending:background
magisk --denylist add com.android.vending com.android.vending:instant_app_installer
magisk --denylist add com.android.vending com.android.vending:com.google.android.finsky.verifier.apkanalysis.service.ApkContentsScanService
magisk --denylist add com.android.vending com.android.vending:recovery_mode
magisk --denylist add com.android.vending com.android.vending:quick_launch
magisk --denylist add com.google.android.ims com.google.android.ims
magisk --denylist add com.google.android.ims com.google.android.ims:crash_report
magisk --denylist add com.google.android.ims com.google.android.ims:primes_lifeboat

# --- [ Banking & Wallets ] ---
magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp
magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp:gib
magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp:container
magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp:phoenix
magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp:playcore_missing_splits_activity
magisk --denylist add com.snb.alahlimobile com.snb.alahlimobile
magisk --denylist add com.snb.alahlimobile com.snb.alahlimobile:gib
magisk --denylist add com.snb.alahlimobile com.snb.alahlimobile:pushservice
magisk --denylist add com.alinma.retail.mobile.v4 com.alinma.retail.mobile.v4
magisk --denylist add sa.com.stcpay sa.com.stcpay
magisk --denylist add sa.com.stcbank sa.com.stcbank
magisk --denylist add com.egyptianbanks.instapay com.egyptianbanks.instapay
magisk --denylist add com.BanqueMisr.MobileBanking com.BanqueMisr.MobileBanking
magisk --denylist add com.CIB.Digital.MB com.CIB.Digital.MB
magisk --denylist add com.ofss.obdx.and.nbe.com.eg com.ofss.obdx.and.nbe.com.eg
magisk --denylist add com.ofss.obdx.and.nbe.com.eg com.ofss.obdx.and.nbe.com.eg:playcore_missing_splits_activity
magisk --denylist add com.fawry.myfawry com.fawry.myfawry
magisk --denylist add com.fawry.myfawry com.fawry.myfawry:remote
magisk --denylist add com.TE.WEWallet com.TE.WEWallet
magisk --denylist add com.etisalat.flous com.etisalat.flous
magisk --denylist add com.orange.eg.money com.orange.eg.money
magisk --denylist add com.orange.eg.money com.orange.eg.money:error_activity
magisk --denylist add com.orange.eg.money com.orange.eg.money:container

# --- [ Government & Official Apps ] ---
magisk --denylist add sa.gov.nic.myid sa.gov.nic.myid
magisk --denylist add sa.gov.nic.twkhayat sa.gov.nic.twkhayat
magisk --denylist add sa.gov.nic.twkhayat sa.gov.nic.twkhayat:container
magisk --denylist add sa.gov.nic.twkhayat sa.gov.nic.twkhayat:pushservice
magisk --denylist add sa.gov.moi sa.gov.moi
magisk --denylist add gov.almadinah.services gov.almadinah.services
magisk --denylist add sa.gov.madina.amana.employees sa.gov.madina.amana.employees
magisk --denylist add sa.gov.madina.amana.employees sa.gov.madina.amana.employees:pushservice
magisk --denylist add sa.gov.madina.amana.employees sa.gov.madina.amana.employees:remote
magisk --denylist add sa.gov.moia.es.amer sa.gov.moia.es.amer
magisk --denylist add com.mosques_managment.moia.gov.sa com.mosques_managment.moia.gov.sa
magisk --denylist add com.mosques_managment.moia.gov.sa com.mosques_managment.moia.gov.sa:pushservice
magisk --denylist add sa.gov.weqaa.employeeswitch sa.gov.weqaa.employeeswitch
magisk --denylist add sa.gov.pv.internal sa.gov.pv.internal
magisk --denylist add mawarid.rcjy.gov.sa mawarid.rcjy.gov.sa

# --- [ HR & Management Systems ] ---
magisk --denylist add com.example.mosque_management_system com.example.mosque_management_system
magisk --denylist add com.menaitech.menaitech com.menaitech.menaitech
magisk --denylist add com.menaitech.mename com.menaitech.mename
magisk --denylist add com.menaitech.mename com.menaitech.mename:FMCrashHandler
magisk --denylist add com.menaitech.mename com.menaitech.mename:container
magisk --denylist add com.menaitech.mename com.menaitech.mename:pushservice
magisk --denylist add ess.android ess.android
magisk --denylist add ess.android ess.android:phoenix
magisk --denylist add ess.android ess.android:pushservice
magisk --denylist add com.mag.takamul com.mag.takamul
magisk --denylist add app.t2.availo app.t2.availo
magisk --denylist add com.t2.AvailoHader com.t2.AvailoHader
magisk --denylist add sa.com.alfursanit.hadirv3 sa.com.alfursanit.hadirv3
magisk --denylist add com.nwc.employee.care com.nwc.employee.care
magisk --denylist add kfshrc.edu.sa.igmob kfshrc.edu.sa.igmob

# --- [ Telecom & Services ] ---
magisk --denylist add com.stc com.stc
magisk --denylist add com.ucare.we com.ucare.we
magisk --denylist add com.ucare.we com.ucare.we:pushservice
magisk --denylist add com.orange.mobinilandme com.orange.mobinilandme
magisk --denylist add com.orange.mobinilandme com.orange.mobinilandme:container
magisk --denylist add com.emeint.android.myservices com.emeint.android.myservices
magisk --denylist add com.competitivetechnology.tvtc com.competitivetechnology.tvtc
magisk --denylist add com.competitivetechnology.tvtc com.competitivetechnology.tvtc:remote
magisk --denylist add sa.alfursan.it.apps.ontimeplus sa.alfursan.it.apps.ontimeplus
magisk --denylist add com.tcs.nim com.tcs.nim
magisk --denylist add com.tcs.nim com.tcs.nim:container
magisk --denylist add com.tcc.manafithauth com.tcc.manafithauth
magisk --denylist add com.tcc.manafithauth.beta com.tcc.manafithauth.beta
magisk --denylist add com.android1500.gpssetter com.android1500.gpssetter

# --- [ Delivery & Logistics ] ---
magisk --denylist add com.logistics.rider.hungerstation com.logistics.rider.hungerstation
magisk --denylist add com.sankuai.sailor.courier com.sankuai.sailor.courier

# --- [ Games & Root Checkers ] ---
magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm
magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:plugin
magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:GP6Service
magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:imsdk_inner_webview
magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:intl_inner_webview
magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:networkDetector
magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:playcore_missing_splits_activity
magisk --denylist add com.tencent.ig com.tencent.ig
magisk --denylist add com.tencent.ig com.tencent.ig:plugin
magisk --denylist add com.tencent.ig com.tencent.ig:playcore_missing_splits_activity
magisk --denylist add com.tencent.ig com.tencent.ig:networkDetector
magisk --denylist add com.tencent.ig com.tencent.ig:intl_inner_webview
magisk --denylist add com.tencent.ig com.tencent.ig:imsdk_inner_webview
magisk --denylist add com.tencent.ig com.tencent.ig:GP6Service
magisk --denylist add com.pubg.krmobile com.pubg.krmobile
magisk --denylist add com.pubg.krmobile com.pubg.krmobile:GP6Service
magisk --denylist add com.pubg.krmobile com.pubg.krmobile:imsdk_inner_webview
magisk --denylist add com.pubg.krmobile com.pubg.krmobile:networkDetector
magisk --denylist add com.pubg.krmobile com.pubg.krmobile:plugin
magisk --denylist add com.pubg.krmobile com.pubg.krmobile:playcore_missing_splits_activity
magisk --denylist add com.pubg.krmobile com.pubg.krmobile:intl_inner_webview
magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile
magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:GP6Service
magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:imsdk_inner_webview
magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:networkDetector
magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:intl_inner_webview
magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:plugin
magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:playcore_missing_splits_activity
magisk --denylist add com.kimchangyoun.rootbeerFresh.sample com.kimchangyoun.rootbeerFresh.sample
magisk --denylist add com.scottyab.rootbeer.sample com.scottyab.rootbeer.sample
magisk --denylist add krypton.tbsafetychecker krypton.tbsafetychecker
magisk --denylist add io.github.vvb2060.keyattestation io.github.vvb2060.keyattestation


# ---------- TrickyStore Auto-Transfer ----------
TRICKY_TARGET="/data/adb/tricky_store/target.txt"
MY_APPS_LIST="$MODPATH/apps_list.txt"

ui_print "- Checking for custom apps list..."

if [ -f "$MY_APPS_LIST" ]; then
    ui_print "- Found apps_list.txt, importing to TrickyStore..."
    
    mkdir -p /data/adb/tricky_store
    
    cp -f "$MY_APPS_LIST" "$TRICKY_TARGET"
    
    chmod 0644 "$TRICKY_TARGET"
    chown 0:0 "$TRICKY_TARGET"
    
    ui_print "- Success: Apps transferred to TrickyStore."
else
    ui_print "! Warning: apps_list.txt not found in module."
fi
