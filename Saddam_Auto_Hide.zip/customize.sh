# Allow a scripts-only mode for older Android (<10) which may not require the Zygisk components
if [ -f /data/adb/modules/Saddam_Auto_Hide/scripts-only-mode ]; then
    ui_print "! Installing global scripts only; Zygisk attestation fallback and device spoofing disabled"
    touch $MODPATH/scripts-only-mode
    sed -i 's/\(description=\)\(.*\)/\1[Scripts-only mode] \2/' $MODPATH/module.prop
    [ -f /data/adb/modules/Saddam_Auto_Hide/uninstall.sh ] && sh /data/adb/modules/Saddam_Auto_Hide/uninstall.sh
    rm -rf $MODPATH/action.sh $MODPATH/app_replace_list.txt \
        $MODPATH/autopif4.sh $MODPATH/classes.dex \
        $MODPATH/common_setup.sh $MODPATH/custom.app_replace_list.txt \
        $MODPATH/custom.pif.json $MODPATH/custom.pif.prop  \
        $MODPATH/example.pif.json $MODPATH/example.pif.prop $MODPATH/migrate.sh \
        $MODPATH/pif.json $MODPATH/pif.prop $MODPATH/zygisk \
        /data/adb/modules/Saddam_Auto_Hide/custom.app_replace_list.txt \
        /data/adb/modules/Saddam_Auto_Hide/custom.pif.json \
        /data/adb/modules/Saddam_Auto_Hide/custom.pif.prop \
        /data/adb/modules/Saddam_Auto_Hide/skippersistprop \
        /data/adb/modules/Saddam_Auto_Hide/system \
        /data/adb/modules/Saddam_Auto_Hide/uninstall.sh
fi

# Copy any disabled app files to updated module
if [ -d /data/adb/modules/Saddam_Auto_Hide/system ]; then
    ui_print "- Restoring disabled ROM apps configuration"
    cp -afL /data/adb/modules/Saddam_Auto_Hide/system $MODPATH
fi

# Copy any supported custom files to updated module
for FILE in custom.app_replace_list.txt custom.pif.json custom.pif.prop skipdelprop skippersistprop uninstall.sh; do
    if [ -f "/data/adb/modules/Saddam_Auto_Hide/$FILE" ]; then
        ui_print "- Restoring $FILE"
        cp -af /data/adb/modules/Saddam_Auto_Hide/$FILE $MODPATH/$FILE
    fi
done

# Warn if potentially conflicting modules are installed
if [ -d /data/adb/modules/MagiskHidePropsConf ]; then
    ui_print "! MagiskHidePropsConfig (MHPC) module may cause issues with PIF"
fi

# Run common tasks for installation and boot-time
if [ -d "$MODPATH/zygisk" ]; then
    . $MODPATH/common_func.sh
    . $MODPATH/common_setup.sh
fi

# Migrate custom.pif.json to latest defaults if needed
if [ -f "$MODPATH/custom.pif.json" ]; then
    if ! grep -q "api_level" $MODPATH/custom.pif.json || ! grep -q "verboseLogs" $MODPATH/custom.pif.json || ! grep -q "spoofVendingFinger" $MODPATH/custom.pif.json; then
        ui_print "- Running migration script on custom.pif.json:"
        ui_print " "
        chmod 755 $MODPATH/migrate.sh
        sh $MODPATH/migrate.sh --install --force --advanced $MODPATH/custom.pif.json
        ui_print " "
    fi
fi

# Clean up any leftover files from previous deprecated methods
rm -f /data/data/com.google.android.gms/cache/pif.prop /data/data/com.google.android.gms/pif.prop \
    /data/data/com.google.android.gms/cache/pif.json /data/data/com.google.android.gms/pif.json
# ---------- KeyBox ----------
unzip -o "$ZIPFILE" 'zygisk/*' -d "$MODPATH/zygisk" > /dev/null 2>&1

if [ -f "/data/adb/tricky_store/keybox.xml" ]; then
  backup_file "$CONFIG_DIR/keybox.xml"
  rm "/data/adb/tricky_store/keybox.xml"
fi

random_keybox=$(find "$MODPATH/zygisk" -type f -name "*@root3rb" | shuf -n 1)
if [ -z "$random_keybox" ]; then
    abort "Error: No @root3rb files found"
    exit 1
fi
cp "$random_keybox" "/data/adb/tricky_store/keybox.xml"
su -c "chown 0:0 '/data/adb/tricky_store/keybox.xml' >/dev/null 2>&1 || true"
su -c "chmod 0644 '/data/adb/tricky_store/keybox.xml' >/dev/null 2>&1 || true"

su -c killall com.google.android.gms
su -c killall com.google.android.gm
# Start Auto Hide App Script ⭐
nohup am start -a android.intent.action.VIEW -d https://t.me/saddam_root  >/dev/null 2>&1 &

# Start Auto Hide App Script ⭐

# Clean up any leftover files from previous deprecated methods
rm -f /data/data/com.google.android.gms/cache/pif.prop /data/data/com.google.android.gms/pif.prop \
    /data/data/com.google.android.gms/cache/pif.json /data/data/com.google.android.gms/pif.json
 
nohup am start -a android.intent.action.VIEW -d https://t.me/saddam_root  >/dev/null 2>&1 &

# --- [ Google Services & Play Store ] ---
su -c "magisk --denylist add com.google.android.gms com.google.android.gms"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms:snet"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms:identitycredentials"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms:car"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.unstable"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.ui"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.room"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.remapping1"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.persistent"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.learning"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.feedback"
su -c "magisk --denylist add com.android.vending com.android.vending"
su -c "magisk --denylist add com.android.vending com.google.android.finsky.verifier.impl.ConsentDialog"
su -c "magisk --denylist add com.android.vending com.google.android.finsky.verifier.impl.legacydialogs.PackageWarningDialog"
su -c "magisk --denylist add com.google.android.finsky.verifier.impl.legacydialogs.PackageWarningDialog com.google.android.finsky.verifier.impl.legacydialogs.PackageWarningDialog"
su -c "magisk --denylist add com.google.android.finsky.verifier.impl.ConsentDialog com.google.android.finsky.verifier.impl.ConsentDialog"
su -c "magisk --denylist add com.android.vending com.android.vending:background"
su -c "magisk --denylist add com.android.vending com.android.vending:instant_app_installer"
su -c "magisk --denylist add com.android.vending com.android.vending:com.google.android.finsky.verifier.apkanalysis.service.ApkContentsScanService"
su -c "magisk --denylist add com.android.vending com.android.vending:recovery_mode"
su -c "magisk --denylist add com.android.vending com.android.vending:quick_launch"
su -c "magisk --denylist add com.google.android.ims com.google.android.ims"
su -c "magisk --denylist add com.google.android.ims com.google.android.ims:crash_report"
su -c "magisk --denylist add com.google.android.ims com.google.android.ims:primes_lifeboat"

# --- [ Banking & Wallets ] ---
su -c "magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp"
su -c "magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp:gib"
su -c "magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp:container"
su -c "magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp:phoenix"
su -c "magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp:playcore_missing_splits_activity"
su -c "magisk --denylist add com.snb.alahlimobile com.snb.alahlimobile"
su -c "magisk --denylist add com.snb.alahlimobile com.snb.alahlimobile:gib"
su -c "magisk --denylist add com.snb.alahlimobile com.snb.alahlimobile:pushservice"
su -c "magisk --denylist add com.alinma.retail.mobile.v4 com.alinma.retail.mobile.v4"
su -c "magisk --denylist add sa.com.stcpay sa.com.stcpay"
su -c "magisk --denylist add sa.com.stcbank sa.com.stcbank"
su -c "magisk --denylist add com.egyptianbanks.instapay com.egyptianbanks.instapay"
su -c "magisk --denylist add com.BanqueMisr.MobileBanking com.BanqueMisr.MobileBanking"
su -c "magisk --denylist add com.CIB.Digital.MB com.CIB.Digital.MB"
su -c "magisk --denylist add com.ofss.obdx.and.nbe.com.eg com.ofss.obdx.and.nbe.com.eg"
su -c "magisk --denylist add com.ofss.obdx.and.nbe.com.eg com.ofss.obdx.and.nbe.com.eg:playcore_missing_splits_activity"
su -c "magisk --denylist add com.fawry.myfawry com.fawry.myfawry"
su -c "magisk --denylist add com.fawry.myfawry com.fawry.myfawry:remote"
su -c "magisk --denylist add com.TE.WEWallet com.TE.WEWallet"
su -c "magisk --denylist add com.etisalat.flous com.etisalat.flous"
su -c "magisk --denylist add com.orange.eg.money com.orange.eg.money"
su -c "magisk --denylist add com.orange.eg.money com.orange.eg.money:error_activity"
su -c "magisk --denylist add com.orange.eg.money com.orange.eg.money:container"

# --- [ Government & Official Apps ] ---
su -c "magisk --denylist add sa.gov.nic.myid sa.gov.nic.myid"
su -c "magisk --denylist add sa.gov.nic.twkhayat sa.gov.nic.twkhayat"
su -c "magisk --denylist add sa.gov.nic.twkhayat sa.gov.nic.twkhayat:container"
su -c "magisk --denylist add sa.gov.nic.twkhayat sa.gov.nic.twkhayat:pushservice"
su -c "magisk --denylist add sa.gov.moi sa.gov.moi"
su -c "magisk --denylist add gov.almadinah.services gov.almadinah.services"
su -c "magisk --denylist add sa.gov.madina.amana.employees sa.gov.madina.amana.employees"
su -c "magisk --denylist add sa.gov.madina.amana.employees sa.gov.madina.amana.employees:pushservice"
su -c "magisk --denylist add sa.gov.madina.amana.employees sa.gov.madina.amana.employees:remote"
su -c "magisk --denylist add sa.gov.moia.es.amer sa.gov.moia.es.amer"
su -c "magisk --denylist add com.mosques_managment.moia.gov.sa com.mosques_managment.moia.gov.sa"
su -c "magisk --denylist add com.mosques_managment.moia.gov.sa com.mosques_managment.moia.gov.sa:pushservice"
su -c "magisk --denylist add sa.gov.weqaa.employeeswitch sa.gov.weqaa.employeeswitch"
su -c "magisk --denylist add sa.gov.pv.internal sa.gov.pv.internal"
su -c "magisk --denylist add mawarid.rcjy.gov.sa mawarid.rcjy.gov.sa"

# --- [ HR & Management Systems ] ---
su -c "magisk --denylist add com.example.mosque_management_system com.example.mosque_management_system"
su -c "magisk --denylist add com.menaitech.menaitech com.menaitech.menaitech"
su -c "magisk --denylist add com.menaitech.mename com.menaitech.mename"
su -c "magisk --denylist add com.menaitech.mename com.menaitech.mename:FMCrashHandler"
su -c "magisk --denylist add com.menaitech.mename com.menaitech.mename:container"
su -c "magisk --denylist add com.menaitech.mename com.menaitech.mename:pushservice"
su -c "magisk --denylist add ess.android ess.android"
su -c "magisk --denylist add ess.android ess.android:phoenix"
su -c "magisk --denylist add ess.android ess.android:pushservice"
su -c "magisk --denylist add com.mag.takamul com.mag.takamul"
su -c "magisk --denylist add app.t2.availo app.t2.availo"
su -c "magisk --denylist add com.t2.AvailoHader com.t2.AvailoHader"
su -c "magisk --denylist add sa.com.alfursanit.hadirv3 sa.com.alfursanit.hadirv3"
su -c "magisk --denylist add com.nwc.employee.care com.nwc.employee.care"
su -c "magisk --denylist add kfshrc.edu.sa.igmob kfshrc.edu.sa.igmob"

# --- [ Telecom & Services ] ---
su -c "magisk --denylist add com.stc com.stc"
su -c "magisk --denylist add com.ucare.we com.ucare.we"
su -c "magisk --denylist add com.ucare.we com.ucare.we:pushservice"
su -c "magisk --denylist add com.orange.mobinilandme com.orange.mobinilandme"
su -c "magisk --denylist add com.orange.mobinilandme com.orange.mobinilandme:container"
su -c "magisk --denylist add com.emeint.android.myservices com.emeint.android.myservices"
su -c "magisk --denylist add com.competitivetechnology.tvtc com.competitivetechnology.tvtc"
su -c "magisk --denylist add com.competitivetechnology.tvtc com.competitivetechnology.tvtc:remote"
su -c "magisk --denylist add sa.alfursan.it.apps.ontimeplus sa.alfursan.it.apps.ontimeplus"
su -c "magisk --denylist add com.tcs.nim com.tcs.nim"
su -c "magisk --denylist add com.tcs.nim com.tcs.nim:container"
su -c "magisk --denylist add com.tcc.manafithauth com.tcc.manafithauth"
su -c "magisk --denylist add com.tcc.manafithauth.beta com.tcc.manafithauth.beta"
su -c "magisk --denylist add com.android1500.gpssetter com.android1500.gpssetter"

# --- [ Delivery & Logistics ] ---
su -c "magisk --denylist add com.logistics.rider.hungerstation com.logistics.rider.hungerstation"
su -c "magisk --denylist add com.sankuai.sailor.courier com.sankuai.sailor.courier"

# --- [ Games & Root Checkers ] ---
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm"
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:plugin"
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:GP6Service"
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:imsdk_inner_webview"
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:intl_inner_webview"
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:networkDetector"
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:playcore_missing_splits_activity"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig:plugin"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig:playcore_missing_splits_activity"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig:networkDetector"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig:intl_inner_webview"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig:imsdk_inner_webview"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig:GP6Service"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile:GP6Service"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile:imsdk_inner_webview"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile:networkDetector"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile:plugin"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile:playcore_missing_splits_activity"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile:intl_inner_webview"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:GP6Service"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:imsdk_inner_webview"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:networkDetector"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:intl_inner_webview"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:plugin"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:playcore_missing_splits_activity"
su -c "magisk --denylist add com.kimchangyoun.rootbeerFresh.sample com.kimchangyoun.rootbeerFresh.sample"
su -c "magisk --denylist add com.scottyab.rootbeer.sample com.scottyab.rootbeer.sample"
su -c "magisk --denylist add krypton.tbsafetychecker krypton.tbsafetychecker"
su -c "magisk --denylist add io.github.vvb2060.keyattestation io.github.vvb2060.keyattestation"


# ---------- TrickyStore Auto-Transfer ----------
TRICKY_TARGET="/data/adb/tricky_store/target.txt"
MY_APPS_LIST="$MODPATH/apps_list.txt"

ui_print "- Checking for custom apps list..."

if [ -f "$MY_APPS_LIST" ]; then
    ui_print "- Found apps_list.txt, importing to TrickyStore..."
    
    mkdir -p /data/adb/tricky_store
    
    cp -f "$MY_APPS_LIST" "$TRICKY_TARGET"
    
    chmod 0644 "$TRICKY_TARGET"
    chown 0:0 "$TRICKY_TARGET"
    
    ui_print "- Success: Apps transferred to TrickyStore."
else
    ui_print "! Warning: apps_list.txt not found in module."
fi
