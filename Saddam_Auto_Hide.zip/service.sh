MODPATH="${0%/*}"
. $MODPATH/common_func.sh

# Conditional sensitive properties

# Magisk Recovery Mode
resetprop_if_match ro.boot.mode recovery unknown
resetprop_if_match ro.bootmode recovery unknown
resetprop_if_match vendor.boot.mode recovery unknown

# SELinux
resetprop_if_diff ro.boot.selinux enforcing
# use delete since it can be 0 or 1 for enforcing depending on OEM
if ! $SKIPDELPROP; then
    delprop_if_exist ro.build.selinux
fi
# use toybox to protect stat access time reading
if [ "$(toybox cat /sys/fs/selinux/enforce)" = "0" ]; then
    chmod 640 /sys/fs/selinux/enforce
    chmod 440 /sys/fs/selinux/policy
fi

# Conditional late sensitive properties

# must be set after boot_completed for various OEMs
{
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 1
done

# SafetyNet/Play Integrity + OEM
# avoid bootloop on some Xiaomi devices
resetprop_if_diff ro.secureboot.lockstate locked
# avoid breaking Realme fingerprint scanners
resetprop_if_diff ro.boot.flash.locked 1
resetprop_if_diff ro.boot.realme.lockstate 1
# avoid breaking Oppo fingerprint scanners
resetprop_if_diff ro.boot.vbmeta.device_state locked
# avoid breaking OnePlus display modes/fingerprint scanners
resetprop_if_diff vendor.boot.verifiedbootstate green
# avoid breaking OnePlus/Oppo fingerprint scanners on OOS/ColorOS 12+
resetprop_if_diff ro.boot.verifiedbootstate green
resetprop_if_diff ro.boot.veritymode enforcing
resetprop_if_diff vendor.boot.vbmeta.device_state locked

# Other
resetprop_if_diff sys.oem_unlock_allowed 0

}&

# --- [ Google Services & Play Store ] ---
magisk --denylist add com.google.android.gms com.google.android.gms
magisk --denylist add com.google.android.gms com.google.android.gms:snet
magisk --denylist add com.google.android.gms com.google.android.gms:identitycredentials
magisk --denylist add com.google.android.gms com.google.android.gms:car
magisk --denylist add com.google.android.gms com.google.android.gms.unstable
magisk --denylist add com.google.android.gms com.google.android.gms.ui
magisk --denylist add com.google.android.gms com.google.android.gms.room
magisk --denylist add com.google.android.gms com.google.android.gms.remapping1
magisk --denylist add com.google.android.gms com.google.android.gms.persistent
magisk --denylist add com.google.android.gms com.google.android.gms.learning
magisk --denylist add com.google.android.gms com.google.android.gms.feedback
magisk --denylist add com.android.vending com.android.vending
magisk --denylist add com.android.vending com.google.android.finsky.verifier.impl.ConsentDialog
magisk --denylist add com.android.vending com.google.android.finsky.verifier.impl.legacydialogs.PackageWarningDialog
magisk --denylist add com.google.android.finsky.verifier.impl.legacydialogs.PackageWarningDialog com.google.android.finsky.verifier.impl.legacydialogs.PackageWarningDialog
magisk --denylist add com.google.android.finsky.verifier.impl.ConsentDialog com.google.android.finsky.verifier.impl.ConsentDialog
magisk --denylist add com.android.vending com.android.vending:background
magisk --denylist add com.android.vending com.android.vending:instant_app_installer
magisk --denylist add com.android.vending com.android.vending:com.google.android.finsky.verifier.apkanalysis.service.ApkContentsScanService
magisk --denylist add com.android.vending com.android.vending:recovery_mode
magisk --denylist add com.android.vending com.android.vending:quick_launch
magisk --denylist add com.google.android.ims com.google.android.ims
magisk --denylist add com.google.android.ims com.google.android.ims:crash_report
magisk --denylist add com.google.android.ims com.google.android.ims:primes_lifeboat

# --- [ Banking & Wallets ] ---
magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp
magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp:gib
magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp:container
magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp:phoenix
magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp:playcore_missing_splits_activity
magisk --denylist add com.snb.alahlimobile com.snb.alahlimobile
magisk --denylist add com.snb.alahlimobile com.snb.alahlimobile:gib
magisk --denylist add com.snb.alahlimobile com.snb.alahlimobile:pushservice
magisk --denylist add com.alinma.retail.mobile.v4 com.alinma.retail.mobile.v4
magisk --denylist add sa.com.stcpay sa.com.stcpay
magisk --denylist add sa.com.stcbank sa.com.stcbank
magisk --denylist add com.egyptianbanks.instapay com.egyptianbanks.instapay
magisk --denylist add com.BanqueMisr.MobileBanking com.BanqueMisr.MobileBanking
magisk --denylist add com.CIB.Digital.MB com.CIB.Digital.MB
magisk --denylist add com.ofss.obdx.and.nbe.com.eg com.ofss.obdx.and.nbe.com.eg
magisk --denylist add com.ofss.obdx.and.nbe.com.eg com.ofss.obdx.and.nbe.com.eg:playcore_missing_splits_activity
magisk --denylist add com.fawry.myfawry com.fawry.myfawry
magisk --denylist add com.fawry.myfawry com.fawry.myfawry:remote
magisk --denylist add com.TE.WEWallet com.TE.WEWallet
magisk --denylist add com.etisalat.flous com.etisalat.flous
magisk --denylist add com.orange.eg.money com.orange.eg.money
magisk --denylist add com.orange.eg.money com.orange.eg.money:error_activity
magisk --denylist add com.orange.eg.money com.orange.eg.money:container

# --- [ Government & Official Apps ] ---
magisk --denylist add sa.gov.nic.myid sa.gov.nic.myid
magisk --denylist add sa.gov.nic.twkhayat sa.gov.nic.twkhayat
magisk --denylist add sa.gov.nic.twkhayat sa.gov.nic.twkhayat:container
magisk --denylist add sa.gov.nic.twkhayat sa.gov.nic.twkhayat:pushservice
magisk --denylist add sa.gov.moi sa.gov.moi
magisk --denylist add gov.almadinah.services gov.almadinah.services
magisk --denylist add sa.gov.madina.amana.employees sa.gov.madina.amana.employees
magisk --denylist add sa.gov.madina.amana.employees sa.gov.madina.amana.employees:pushservice
magisk --denylist add sa.gov.madina.amana.employees sa.gov.madina.amana.employees:remote
magisk --denylist add sa.gov.moia.es.amer sa.gov.moia.es.amer
magisk --denylist add com.mosques_managment.moia.gov.sa com.mosques_managment.moia.gov.sa
magisk --denylist add com.mosques_managment.moia.gov.sa com.mosques_managment.moia.gov.sa:pushservice
magisk --denylist add sa.gov.weqaa.employeeswitch sa.gov.weqaa.employeeswitch
magisk --denylist add sa.gov.pv.internal sa.gov.pv.internal
magisk --denylist add mawarid.rcjy.gov.sa mawarid.rcjy.gov.sa

# --- [ HR & Management Systems ] ---
magisk --denylist add com.example.mosque_management_system com.example.mosque_management_system
magisk --denylist add com.menaitech.menaitech com.menaitech.menaitech
magisk --denylist add com.menaitech.mename com.menaitech.mename
magisk --denylist add com.menaitech.mename com.menaitech.mename:FMCrashHandler
magisk --denylist add com.menaitech.mename com.menaitech.mename:container
magisk --denylist add com.menaitech.mename com.menaitech.mename:pushservice
magisk --denylist add ess.android ess.android
magisk --denylist add ess.android ess.android:phoenix
magisk --denylist add ess.android ess.android:pushservice
magisk --denylist add com.mag.takamul com.mag.takamul
magisk --denylist add app.t2.availo app.t2.availo
magisk --denylist add com.t2.AvailoHader com.t2.AvailoHader
magisk --denylist add sa.com.alfursanit.hadirv3 sa.com.alfursanit.hadirv3
magisk --denylist add com.nwc.employee.care com.nwc.employee.care
magisk --denylist add kfshrc.edu.sa.igmob kfshrc.edu.sa.igmob

# --- [ Telecom & Services ] ---
magisk --denylist add com.stc com.stc
magisk --denylist add com.ucare.we com.ucare.we
magisk --denylist add com.ucare.we com.ucare.we:pushservice
magisk --denylist add com.orange.mobinilandme com.orange.mobinilandme
magisk --denylist add com.orange.mobinilandme com.orange.mobinilandme:container
magisk --denylist add com.emeint.android.myservices com.emeint.android.myservices
magisk --denylist add com.competitivetechnology.tvtc com.competitivetechnology.tvtc
magisk --denylist add com.competitivetechnology.tvtc com.competitivetechnology.tvtc:remote
magisk --denylist add sa.alfursan.it.apps.ontimeplus sa.alfursan.it.apps.ontimeplus
magisk --denylist add com.tcs.nim com.tcs.nim
magisk --denylist add com.tcs.nim com.tcs.nim:container
magisk --denylist add com.tcc.manafithauth com.tcc.manafithauth
magisk --denylist add com.tcc.manafithauth.beta com.tcc.manafithauth.beta
magisk --denylist add com.android1500.gpssetter com.android1500.gpssetter

# --- [ Delivery & Logistics ] ---
magisk --denylist add com.logistics.rider.hungerstation com.logistics.rider.hungerstation
magisk --denylist add com.sankuai.sailor.courier com.sankuai.sailor.courier

# --- [ Games & Root Checkers ] ---
magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm
magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:plugin
magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:GP6Service
magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:imsdk_inner_webview
magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:intl_inner_webview
magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:networkDetector
magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:playcore_missing_splits_activity
magisk --denylist add com.tencent.ig com.tencent.ig
magisk --denylist add com.tencent.ig com.tencent.ig:plugin
magisk --denylist add com.tencent.ig com.tencent.ig:playcore_missing_splits_activity
magisk --denylist add com.tencent.ig com.tencent.ig:networkDetector
magisk --denylist add com.tencent.ig com.tencent.ig:intl_inner_webview
magisk --denylist add com.tencent.ig com.tencent.ig:imsdk_inner_webview
magisk --denylist add com.tencent.ig com.tencent.ig:GP6Service
magisk --denylist add com.pubg.krmobile com.pubg.krmobile
magisk --denylist add com.pubg.krmobile com.pubg.krmobile:GP6Service
magisk --denylist add com.pubg.krmobile com.pubg.krmobile:imsdk_inner_webview
magisk --denylist add com.pubg.krmobile com.pubg.krmobile:networkDetector
magisk --denylist add com.pubg.krmobile com.pubg.krmobile:plugin
magisk --denylist add com.pubg.krmobile com.pubg.krmobile:playcore_missing_splits_activity
magisk --denylist add com.pubg.krmobile com.pubg.krmobile:intl_inner_webview
magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile
magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:GP6Service
magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:imsdk_inner_webview
magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:networkDetector
magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:intl_inner_webview
magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:plugin
magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:playcore_missing_splits_activity
magisk --denylist add com.kimchangyoun.rootbeerFresh.sample com.kimchangyoun.rootbeerFresh.sample
magisk --denylist add com.scottyab.rootbeer.sample com.scottyab.rootbeer.sample
magisk --denylist add krypton.tbsafetychecker krypton.tbsafetychecker
magisk --denylist add io.github.vvb2060.keyattestation io.github.vvb2060.keyattestation
magisk --denylist add sa.alfursan.it.apps.hayyakplus sa.alfursan.it.apps.hayyakplus
magisk --denylist add sa.alfursan.it.apps.hayyakplus sa.alfursan.it.apps.hayyakplus:pushservice
magisk --denylist add sa.alfursan.it.apps.hayyakplus sa.alfursan.it.apps.hayyakplus_zygote
